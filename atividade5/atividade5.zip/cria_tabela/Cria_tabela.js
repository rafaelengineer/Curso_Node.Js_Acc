//Necessário ser criado previamente o Schema "node_atividade5" no MySql
//No Arquivo config.js, nome do Schema: node_atividade5

const Sequelize = require("sequelize");
const sequelize = require("./config");

const Produto = sequelize.define("Cep", {
  id: {
    type: Sequelize.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  cep: {
    type: Sequelize.STRING,
  },
  logradouro: {
    type: Sequelize.STRING,
  },
  complemento: {
    type: Sequelize.STRING,
  },
  bairro: {
    type: Sequelize.STRING,
  },
  localidade: {
    type: Sequelize.STRING,
  },
  uf: {
    type: Sequelize.STRING,
  },
  ibge: {
    type: Sequelize.STRING,
  },
  gia: {
    type: Sequelize.STRING,
  },
  ddd: {
    type: Sequelize.STRING,
  },
  siafi: {
    type: Sequelize.STRING,
  },
}, {
  timestamps: false,
  tableName: "Cep_s"
});


sequelize.sync().then(() => {
  console.log("Modelo sincronizado com o banco de dados");
}).catch((err) => {
  console.error("Erro na sincronização com o banco de dados:", err);
});